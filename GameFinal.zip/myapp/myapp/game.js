var game = function(gameID) {
    this.playerA = null;
    this.playerB = null;
    this.id = gameID;
  };

game.prototype.addPlayer = function(p) {
    if (this.playerA == null) {
      this.playerA = p;
      return "A";
    } else {
      this.playerB = p;
      return "B";
    }
}
game.prototype.getOtherPlayer=function(p){
    if(p===this.playerA)
        return this.playerB;
    else
        return this.playerA;
}

game.prototype.hasTwoConnectedPlayers=function(){
    if(this.playerA!=null && this.playerB!=null)
        return true;
    return false;
}

module.exports = game;