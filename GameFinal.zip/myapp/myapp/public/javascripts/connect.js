var connection= new WebSocket("ws://localhost:3000");
function sendCeva(message){
     connection.send(message);
}
function sentPos(){
    //TODO:
}
connection.onmessage= function(e){
    console.log(e.data);
    if( plyr == undefined ){
       plyr = e.data;
    }else{
        //Other Messages
    }
    
    /*console.log("[Socket] " + e.data);
    if(game.isMyTurn == undefined){
        if(obj.turn===1)
            game.isMyTurn = true;
        else
            game.isMyTurn = false;
        console.log("Is my turn?" + game.isMyTurn)
    }else{

    }*/ 
}