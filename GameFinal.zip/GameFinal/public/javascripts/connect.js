var connection= new WebSocket("ws://localhost:3000");
function sendCeva(){
connection.send(JSON.stringify("hii"));
}
connection.onmessage= function(e){
    var x=JSON.stringify(e)
    console.log(x);
    
}