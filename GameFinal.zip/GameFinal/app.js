
var express = require("express");
var http = require("http");
var websocket = require("ws");

var indexRouter = require("./routes/index");

//var gameStatus = require("./statTracker");
//var Game = require("./game");

var port = process.argv[2];
var app = express();
app.get("/",indexRouter);
app.set("view engine", "ejs");
app.use(express.static(__dirname + "/public"));

app.get("/tadam", indexRouter);
//TODO: move to routes/index
//app.get("/", (req, res) => {
//   res.render("splash.ejs", {
//     gamesInitialized: gameStatus.gamesInitialized,
//     gamesCompleted: gameStatus.gamesCompleted
//   });
// });

var server = http.createServer(app).listen(port,function(){
    console.log((new Date())+ 'Server is listening to port'+port);
});
const wss = new websocket.Server({ server });
var websockets = {};


//var currentGame = new Game(gameStatus.gamesInitialized++);
var connectionID = 0;

wss.on("connection", function (ws) {
    ws.on("message", function(w){
        var obj=JSON.parse(w);
        
        ws.send("hi");
        console.log(obj);
    })
    ws.on('close',function(){
        console.log('connection closed');
    })
})