var cols =7;
var rows=6;
var turn=0;
var first=1;




//if(plyr!=undefined){
    function makeMatrix(cols,rows){
        var arr= new Array(cols);
        for(var i=0; i<arr.length;i++){
            arr[i]=new Array(rows);
        }
        return arr;
    }
    
    var game=document.getElementById('game');
    var grid=makeMatrix(7,6);
    for(var i=0;i<rows;i++){
        let param=document.createElement("div")
        param.setAttribute("class","row")
        param.setAttribute("id",i)
        let element = document.getElementById("game");
        element.appendChild(param);
        for(var j=0;j<cols;j++){
            grid[i][j]="";
            let colum = document.createElement("div");
            colum.setAttribute("class","colum")
            colum.setAttribute("row",i)
            colum.setAttribute("col",j)
            //console.log(grid[i][j])
            let node1 = document.createTextNode(grid[i][j]);
            colum.appendChild(node1);
            param.appendChild(colum);
                //if(plyr=="A")
                    //console.log("LUL")
                
                colum.addEventListener("click",function(){
                    let q= document.getElementById("myAudio"); 
                    q.play();
                    console.log(turn);
                    if(plyr==="A"&&first==1){
                        first=0
                        turn=1
                    }
                    /*if(plyr==="A")
                        colum.setAttribute("color","red")
                    else
                    colum.setAttribute("color","black")
                    */
                    //console.log(colum.getAttribute("row")+" "+colum.getAttribute("col"));
                    console.log(turn)
                    /*if(turn==0){
                       let x= document.getElementById("player")
                       x.textContent="plyr"
                       console.log(x);
                    }*/

                    if(turn==1){
                    
                    let i=colum.getAttribute("row");
                    let j=colum.getAttribute("col")
                    var pos={
                        row:i,
                        colum:j,
                        player:plyr
                    }
                    //console.log(document.querySelectorAll(`div[row="${i}"][col="${j}"]`)[0])
                    sendClickPos(pos);
                    }
                
                })
                //console.log(plyr);
            
        }
    }
    //
    
    function addColor(row,colum,player){
        let obj=(document.querySelectorAll(`div[row="${row}"][col="${colum}"]`)[0]);
        console.log(obj);
        let color;
        if(plyr==="A")
                    //obj.setAttribute("color","black")
            color="red"
        else
            color="black"    
            //obj.setAttribute("color","red")
        if(player===plyr){
            obj.setAttribute("color",color)
            //alert(plyr);
            turn=0;
        }else{
            turn=1;
            if(color==="red")
                obj.setAttribute("color","black")
            else
                obj.setAttribute("color","red")
        }
        console.log(turn)

    }
    function goMove(){
        turn=1;
    }
   /* var colum=document.getElementsByClassName("colum")
            //console.log(colum[i]);
    for(let i=0;i<42;i++){
            colum[i].addEventListener("click",function(){
                console.log(plyr);
                if(plyr==="A")
                    colum[i].setAttribute("color","red")
                else
                colum[i].setAttribute("color","black")
                
                console.log(colum[i].getAttribute("row")+" "+colum[i].getAttribute("col"));
                console.log(document.querySelectorAll('div[row="1"][col="1"]')[0])
            })
        }
//}*/


        function setTime()
        {
            ++totalSeconds;
            secondsLabel.innerHTML = pad(totalSeconds%60);
            minutesLabel.innerHTML = pad(parseInt(totalSeconds/60));
        }

        function pad(val)
        {
            var valString = val + "";
            if(valString.length < 2)
            {
                return "0" + valString;
            }
            else
            {
                return valString;
            }
        }
        function setPlayerOnBoard(color){
            let redCircle = document.getElementsByClassName("RED")[0].getElementsByTagName("p")[0];
            let blackCircle=document.getElementsByClassName("BLACK")[0].getElementsByTagName("p")[0];
            if(color=="A"){
                redCircle.appendChild(document.createTextNode("YOU"))
                blackCircle.appendChild(document.createTextNode("OPPONENT"))
            }
            if(color=="B"){
                redCircle.appendChild(document.createTextNode("OPPONENT"))
                blackCircle.appendChild(document.createTextNode("YOU"))
            }
            
        }
        function addHilight(color){
            let redCircle = document.getElementsByClassName("RED")[0];
            let blackCircle=document.getElementsByClassName("BLACK")[0];
            if(color=="A"){
                redCircle.removeAttribute("isHi")
                blackCircle.setAttribute("isHi","yes")
                console.log("color")
            }
            if(color=="B"){
                redCircle.setAttribute("isHi","yes")
                blackCircle.removeAttribute("isHi")
                console.log("color")
            }
        }
        function addHilightf(color){
            let redCircle = document.getElementsByClassName("RED")[0];
            
           
            if(color=="A"){
                redCircle.setAttribute("isHi","yes")
                
                console.log("color")
            }
        }
         
        function openFullScreen() {
            let element = document.getElementsByTagName("html")[0];
            
            /*if (document.requestFullscreen) {
                document.requestFullscreen();
              } else if (document.mozRequestFullScreen) { 
                document.mozRequestFullScreen();
              } else if (document.webkitRequestFullscreen) { 
                document.webkitRequestFullscreen();
              } else if (document.msRequestFullscreen) { 
                document.msRequestFullscreen();
              }*/
              element.requestFullscreen()
              console.log(document);
    }
function setCookie(){

    var cookiesArray = document.cookie.split('; ');
    var cookies=[];
    for(var i=0; i < cookiesArray.length; i++) {
        var cookie = cookiesArray[i].split("=");
        cookies[cookie[0]]=cookie[1];
    }
    if(document.cookie==""){
        document.cookie = "visit=1";
    }else{
        document.cookie= "visit="+(parseInt(cookies.visit,10)+1)
    }
    //let v=document.getElementsByClassName("visited")[0]
    //console.log(v);
    document.getElementsByClassName("here")[0].appendChild(document.createTextNode(cookies.visit))
}












