var game = function(gameID) {
    this.playerA = null;
    this.playerB = null;
    this.id = gameID;
    this.gameBoard = [
      [0, 0, 0, 0, 0, 0, 0], 
      [0, 0, 0, 0, 0, 0, 0], 
      [0, 0, 0, 0, 0, 0, 0], 
      [0, 0, 0, 0, 0, 0, 0], 
      [0, 0, 0, 0, 0, 0, 0], 
      [0, 0, 0, 0, 0, 0, 0], 
    ];
  };

game.prototype.checkLeft=function(row,colum){

}
game.prototype.checkRight=function(row,colum){

}
game.prototype.checkUp=function(row,colum){

}
game.prototype.checkBottom=function(row,colum){

}
game.prototype.checkDiagonala=function(row,colum){

}

game.prototype.checkRowToUse = function(row,colum){
  let rowcheck=5;
  //return rowcheck;
  while(rowcheck != -1){
    if(this.gameBoard[rowcheck][colum] === 0){
      console.log(rowcheck)
      return rowcheck;
    }else{
      rowcheck--;
    }
  }
  return "Wrong Move!"
}
game.prototype.isValidMove = function(row,colum,player){
  let rowcheck=0;
    if(player=="A"){
        rowcheck=this.checkRowToUse(row,colum);
        if(rowcheck != "Wrong Move!"){
            this.gameBoard[rowcheck][colum]=1;
            var pos={
              row: rowcheck,
              colum:colum,
              player:player
          }
          return JSON.stringify(pos)
        }else{
            return "Wrong Move!"
        }
    }
    if(player=="B")
    rowcheck=this.checkRowToUse(row,colum);
    if(rowcheck != "Wrong Move!"){
        this.gameBoard[rowcheck][colum]=2;
        var pos={
          row: rowcheck,
          colum:colum,
          player:player
      }
      return JSON.stringify(pos)
    }else{
        return "Wrong Move!"
    }
return "Wrong Move!"
}



game.prototype.addPlayer = function(p) {
    if (this.playerA == null) {
      this.playerA = p;
      return "A";
    } else {
      this.playerB = p;
      return "B";
    }
}
game.prototype.getOtherPlayer=function(p){
    if(p===this.playerA)
        return this.playerB;
    else
        return this.playerA;
}

game.prototype.hasTwoConnectedPlayers=function(){
    if(this.playerA!=null && this.playerB!=null)
        return true;
    return false;
}

module.exports = game;