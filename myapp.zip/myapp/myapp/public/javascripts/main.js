var cols =7;
var rows=6;
var turn=0;
var first=1;




//if(plyr!=undefined){
    function makeMatrix(cols,rows){
        var arr= new Array(cols);
        for(var i=0; i<arr.length;i++){
            arr[i]=new Array(rows);
        }
        return arr;
    }
    var game=document.getElementById('game');
    var grid=makeMatrix(7,6);
    for(var i=0;i<rows;i++){
        let param=document.createElement("div")
        param.setAttribute("class","row")
        param.setAttribute("id",i)
        let element = document.getElementById("game");
        element.appendChild(param);
        for(var j=0;j<cols;j++){
            grid[i][j]="";
            let colum = document.createElement("div");
            colum.setAttribute("class","colum")
            colum.setAttribute("row",i)
            colum.setAttribute("col",j)
            //console.log(grid[i][j])
            let node1 = document.createTextNode(grid[i][j]);
            colum.appendChild(node1);
            param.appendChild(colum);
           
                
                colum.addEventListener("click",function(){
                    console.log(turn);
                    if(plyr==="A"&&first==1){
                        first=0
                        turn=1
                    }
                    /*if(plyr==="A")
                        colum.setAttribute("color","red")
                    else
                    colum.setAttribute("color","black")
                    */
                    //console.log(colum.getAttribute("row")+" "+colum.getAttribute("col"));
                    console.log(turn)
                    if(turn==1){
                    
                    let i=colum.getAttribute("row");
                    let j=colum.getAttribute("col")
                    var pos={
                        row:i,
                        colum:j,
                        player:plyr
                    }
                    //console.log(document.querySelectorAll(`div[row="${i}"][col="${j}"]`)[0])
                    sendClickPos(pos);
                    }
                
                })
                //console.log(plyr);
            
        }
    }
    //
    
    function addColor(row,colum,player){
        let obj=(document.querySelectorAll(`div[row="${row}"][col="${colum}"]`)[0]);
        console.log(obj);
        let color;
        if(plyr==="A")
                    //obj.setAttribute("color","black")
            color="red"
        else
            color="black"    
            //obj.setAttribute("color","red")
        if(player===plyr){
            obj.setAttribute("color",color)
            turn=0;
        }else{
            turn=1;
            if(color==="red")
                obj.setAttribute("color","black")
            else
                obj.setAttribute("color","red")
        }
        console.log(turn)

    }
    function goMove(){
        turn=1;
    }
   /* var colum=document.getElementsByClassName("colum")
            //console.log(colum[i]);
    for(let i=0;i<42;i++){
            colum[i].addEventListener("click",function(){
                console.log(plyr);
                if(plyr==="A")
                    colum[i].setAttribute("color","red")
                else
                colum[i].setAttribute("color","black")
                
                console.log(colum[i].getAttribute("row")+" "+colum[i].getAttribute("col"));
                console.log(document.querySelectorAll('div[row="1"][col="1"]')[0])
            })
        }
//}*/
























/*var plyr;

$(document).ready( setTimeout( function(){
    const game = new Game(plyr);
    
    //game.playerSwitch=function(){
   //     $('#player').text(game.player);
   // }
    $('#restart').click(function(){
        game.restart();
    })
}), 3000);


class Game{
    constructor(player){
        this.ROWS=6;
        this.COLS=7;
        console.log(player);
        if(player == "A")
            this.player='red';
        else
            this.player='black';
        this.isGameOver=false;
        this.selector='#game';
        this.createGrid();
        this.setupEventListeners();
        //this.otherPlayer();
        
    }
    /*otherPlayer(){
        connection.onmessage= function(e){
            e.removeClass(`empty next-${this.player}`);
            e.addClass(this.player);
            e.data('player',this.player);
        }
        
    }*//*
    createGrid(){
        const $board= $(this.selector); 
        $board.empty();
        this.isGameOver=false;
        //this.player='red';
        
        for(let row=0;row<this.ROWS;row++){
            const $row= $('<div>').addClass('row');
            for(let col=0;col<this.COLS;col++){
                const $col= $('<div>').addClass('col empty').attr('data-col',col).attr('data-row',row);
                $row.append($col);
            }
            $board.append($row);
        }
        
    }
    setupEventListeners(){
        const $board = $(this.selector);
        const that=this;
        function gasesteLastEmptyCell(col){
            const cells=$(`.col[data-col='${col}']`);
            for(let i=cells.length-1;i>=0;i--){
                const $cell=$(cells[i]);
                if($cell.hasClass('empty')){
                    return $cell;
                }
            }
            return null;
        }
        $board.on('mouseenter','.col.empty',function(){

            if(that.isGameOver)return;  


            const col=$(this).data('col');
            const $lastEmptyCell = gasesteLastEmptyCell(col);
            $lastEmptyCell.addClass(`next-${that.player}`);
            
        });
        $board.on('mouseleave','.col',function(){
            $('.col').removeClass(`next-${that.player}`);
        });
        $board.on('click','.col.empty',function(){
            sendCeva();
            const col=$(this).data('col');
            console.log(col);
            const $lastEmptyCell = gasesteLastEmptyCell(col);
            
            connection.send(col);

            //console($lastEmptyCell.data('col'));
            $lastEmptyCell.removeClass(`empty next-${that.player}`);
            $lastEmptyCell.addClass(that.player);
            $lastEmptyCell.data('player',that.player);


            const winner = that.checkForWinner($lastEmptyCell.data('row'),$lastEmptyCell.data('col'));
            if(winner){
                that.isGameOver=true;
                setTimeout(function(){alert(`Game Over! Player ${that.player} has won!`);},100);
                $('.col.empty').removeClass('empty');
                return;
            }
            
            //that.player=(that.player==='red')? 'black':'red';
            //that.playerSwitch();
            $(this).trigger('mouseenter');
            
        });
    }
    checkForWinner(row,col){
        const that=this;
        function $getCell(i,j){
            return $(`.col[data-row='${i}'][data-col='${j}']`);
        }
        function checkDirectie(directie){
            let total=0;
            let i=row+directie.i;
            let j=col+directie.j;
            let $next=$getCell(i,j);
            while(i>=0 && i<that.ROWS&&j>=0&&j<that.COLS && $next.data('player')===that.player){
                total++;
                i+=directie.i;
                j+=directie.j;
                $next=$getCell(i,j);
            }
            return total;
        }
        function checkWin(directieA,directieB){
            const total=1+
                checkDirectie(directieA)+
                checkDirectie(directieB);
            if(total >= 4){
                return that.player;
            }else{
                return null;
            }
        }
        function checkDiagonalaStangaJosLaDreaptaSus(){
            return checkWin({i:1,j:-1},{i:1,j:1});
        }
        function checkDiagonalaStangaSusLaDreaptaJos(){
            return checkWin({i:1,j:1},{i:-1,j:-1});
        }
        function checkVerticala(){
            return checkWin({i:-1,j:0},{i:1,j:0});
        }
        function checkOrizontala(){
            return checkWin({i:0,j:-1},{i:0,j:1});
        }
        return checkVerticala()||checkOrizontala()||checkDiagonalaStangaJosLaDreaptaSus()||checkDiagonalaStangaSusLaDreaptaJos();
    }
    restart(){
        this.createGrid();
        //this.playerSwitch();
    }

}*/