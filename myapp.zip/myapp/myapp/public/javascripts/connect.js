
var connection= new WebSocket("ws://localhost:3000");
var plyr;//Pocola was here
function sendClickPos(message){
     connection.send(JSON.stringify(message));
     console.log(i);
}
function sentPos(){
    //TODO:
}
function getPlyr(){
    return plyr;
}
connection.onmessage= function(e){
    console.log(e.data);
    if( plyr == undefined ){
        plyr=e.data
        console.log(plyr)
       
    }else if(e.data==="StartGame"){
        console.log("XD")
            $('.loadingOverlay').hide();

    }else if(e.data=="Wrong Move!"){
        goMove();

    }else{
        let obj=JSON.parse(e.data);
        //console.log(obj.row);
        addColor(obj.row,obj.colum,obj.player);
        console.log(obj.xd);
       /* if( obj.hasPlayer==1){
            console.log("XD")
            $('.loadingOverlay').hide();
        }*/
    }
    
    /*console.log("[Socket] " + e.data);
    if(game.isMyTurn == undefined){
        if(obj.turn===1)
            game.isMyTurn = true;
        else
            game.isMyTurn = false;
        console.log("Is my turn?" + game.isMyTurn)
    }else{

    }*/ 
}