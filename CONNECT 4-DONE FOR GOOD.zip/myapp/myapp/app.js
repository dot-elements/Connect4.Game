
var express = require("express");
var http = require("http");
var websocket = require("ws");
var cnt=0;

var indexRouter = require("./routes/index");

var gameStatus = require("./statTracker");
var Game = require("./game");

var port = process.argv[2];
var app = express();
//app.get("/",indexRouter);
app.set("view engine", "ejs");
app.use(express.static(__dirname + "/public"));

app.get("/tadam", indexRouter);
//TODO: move to routes/index
app.get("/", (req, res) => {
    res.render("splash.ejs", {
      curGames: gameStatus.curGames,
      gamesCompleted: gameStatus.gamesCompleted
    });
  });
var server = http.createServer(app).listen(port,function(){
    console.log((new Date())+ 'Server is listening to port'+port);
});
const wss = new websocket.Server({ server });
var websockets = {};



var connectionID = 0;

var curGames = 0;
var currentGame = new Game(curGames++);
wss.on("connection", function (ws) {
  /*
   * two-player game: every two players are added to the same game
   */
  let con = ws;
  con.id = connectionID++;
  let playerType = currentGame.addPlayer(con);
  websockets[con.id] = currentGame;
  con.send(playerType);
  

  console.log(
    "Player %s placed in game %s as %s",
    con.id,
    currentGame.id,
    playerType
  );

  /*
   * inform the client about its assigned player type
   */
  //con.send(playerType == "A" ? messages.S_PLAYER_A : messages.S_PLAYER_B);*/    
   /* if (currentGame.hasTwoConnectedPlayers()) 
    {
        currentGame = new Game(gameStatus.curGames);
    }
    else
    {
        gameStatus.curGames++;
    }*/
    if (currentGame.hasTwoConnectedPlayers()) {
        con.send("StartGame");
        let x=websockets[con.id];
        let otherPlayer=x.getOtherPlayer(con);
        otherPlayer.send("StartGame")
        console.log(gameStatus.curGames);
        currentGame = new Game(curGames++);
        gameStatus.curGames++;
    }
    con.on("message", function(w){
        let gameObj = websockets[con.id];
        let otherPlayer=gameObj.getOtherPlayer(con);
        console.log(otherPlayer.id);
        //if(w.data!=)
        //con.send(w);
        let x=JSON.parse(w);
        x=gameObj.isValidMove(x.row,x.colum,x.player);
        if(x.data!="Wrong Move!"){
        x=JSON.parse(x);
            
            //let y=gameObj.checkForWinner(x.row,x.colum,gameObj.gameBoard)
            if(gameObj.Horz(x.player)||gameObj.Vert(x.player)||gameObj.Diag1(x.player)||gameObj.Diag2(x.player)){
                console.log("E GATA");
                con.send("YOU WIN")
                otherPlayer.send("YOU LOSE");
            }
                        
            //console.log(gameObj.gameBoard);
            x=JSON.stringify(x)
            //console.log(y);
            //console.log(gameObj.gameBoard)
        }
        con.send(x)
        otherPlayer.send(x);
        
    })


    con.on('close',function(){
        let gameObj = websockets[con.id];
        let otherPlayer=gameObj.getOtherPlayer(con);
        otherPlayer.send("GameDisconnect");
        console.log('connection closed');
        if(cnt%2==0)
            gameStatus.gamesCompleted++;
        cnt++;
    })
})


