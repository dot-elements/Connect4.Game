var game = function(gameID) {
    this.playerA = null;
    this.playerB = null;
    this.id = gameID;
    this.gameBoard = [
      [0, 0, 0, 0, 0, 0, 0], 
      [0, 0, 0, 0, 0, 0, 0], 
      [0, 0, 0, 0, 0, 0, 0], 
      [0, 0, 0, 0, 0, 0, 0], 
      [0, 0, 0, 0, 0, 0, 0], 
      [0, 0, 0, 0, 0, 0, 0], 
    ];
  };

game.prototype.orizontala=function(row,colum){
  let j=colum+1;
  
  for(let j1=j;j1<6;j1++){
    if(this.gameBoard[row][j1]!=this.gameBoard[row][colum]){
        j=j1-1;
        break;
    }  
    else
      j=j1;
  }
  let cnt=0;
  for(j;j>=0;j--){
    if(this.gameBoard[row][colum]==this.gameBoard[row][j])
      cnt++;
  }
  console.log(cnt);
  if(cnt>=4)
    return true;
  return false;
}

game.prototype.checkUp=function(row,colum){
  let wincheck=false;
  let i=row;
  if(row<=2){
    if(this.gameBoard[i+1][colum]===this.gameBoard[row][colum] && this.gameBoard[i+2][colum]===this.gameBoard[row][colum] && this.gameBoard[i+3][colum]===this.gameBoard[row][colum]){
      wincheck=true;
    }
  }
  return wincheck;
}
game.prototype.checkBottom=function(row,colum){
  let wincheck=false;
  let i=row;
  if(row>=3){
    if(this.gameBoard[i-1][colum]===this.gameBoard[row][colum] && this.gameBoard[i-2][colum] === this.gameBoard[row][colum] && this.gameBoard[i-3][colum]===this.gameBoard[row][colum]){
      wincheck=true;
    }
  }
  return wincheck;
}                                 

game.prototype.checkDiagonalla=function(row,colum){
  for(var col=0;col<=3;col++){
    for(var row1=0;row1<=2;row1++){
      if(this.gameBoard[row][colum]===this.gameBoard[row1][col] && this.gameBoard[row][colum]===this.gameBoard[row1+1][col+1] && this.gameBoard[row][colum]===this.gameBoard[row1+2][col+2] && this.gameBoard[row][colum]===this.gameBoard[row1+3][col+3]){
        return true;
      }
    }
    for(row1=3;row1<=5;row1++){
      if(this.gameBoard[row][colum]===this.gameBoard[row1][col] && this.gameBoard[row][colum]===this.gameBoard[row1+1][col+1] && this.gameBoard[row][colum]===this.gameBoard[row1+2][col+2] && this.gameBoard[row][colum]===this.gameBoard[row1+3][col+3]){
        return true;
      }
    }
  }
  return false;
}
/*game.prototype.checkDiagonalaLeft=function(row,colum){
    let i=row-1;
    let j=colum-1;
    let j1;
    let i1;
    let cnt =0;
    while(j!=-1||i!=-1){
      if(this.gameBoard[i][j]!=this.gameBoard[row][colum]){
        j1=j+1;
        i1=i+1;
        break;
      }
      j1=j;
      i1=i;
      j--;
      i--;
    }
    while(j!=7||i!=7){
      if(this.gameBoard[i][j]!=this.gameBoard[row][colum]){
        cnt++;
        console.log(cnt);
      }
      j++;
      i++;
    }
    if(cnt>=4 )
      return true;
    return false;
}*/



game.prototype.checkRowToUse = function(row,colum){
  let rowcheck=5;
  //return rowcheck;
  while(rowcheck != -1){
    if(this.gameBoard[rowcheck][colum] === 0){
      console.log(rowcheck)
      return rowcheck;
    }else{
      rowcheck--;
    }
  }
  return "Wrong Move!";
}

game.prototype.checkWin = function(row,colum,player){
  if(player=="A")
  {
    console.log("player")
    if(this.checkBottom(row,colum)==true || this.Vert()==true  || this.orizontala(row,colum)==true ||this.Horz()==true)
    {
      return true;
    }
    else 
    {
      
      return false;
    }
  }
  if(player=="B")
  {
    if(this.checkBottom(row,colum)===true || this.Vert()===true || this.orizontala(row,colum)===true || this.Horz()==true){
      return true;
    }
    else
    {
      return false;
    }
    }
}


game.prototype.isValidMove = function(row,colum,player){
  let rowcheck=0;
    if(player=="A"){
        rowcheck=this.checkRowToUse(row,colum);
        if(rowcheck != "Wrong Move!"){
            this.gameBoard[rowcheck][colum]=1;
            var pos={
              row: rowcheck,
              colum:colum,
              player:player
          }
          return JSON.stringify(pos)
        }else{
            return "Wrong Move!"
        }
    }
    if(player=="B")
    rowcheck=this.checkRowToUse(row,colum);
    if(rowcheck != "Wrong Move!"){
        this.gameBoard[rowcheck][colum]=2;
        var pos={
          row: rowcheck,
          colum:colum,
          player:player
      }
      return JSON.stringify(pos)
    }else{
        return "Wrong Move!"
    }
//return "Wrong Move!"
}



game.prototype.addPlayer = function(p) {
    if (this.playerA == null) {
      this.playerA = p;
      return "A";
    } else {
      this.playerB = p;
      return "B";
    }
}
game.prototype.getOtherPlayer=function(p){
    if(p===this.playerA)
        return this.playerB;
    else
        return this.playerA;
}

game.prototype.hasTwoConnectedPlayers=function(){
    if(this.playerA!=null && this.playerB!=null)
        return true;
    return false;
}
game.prototype.Horz=function(player){
  let type=null
if(player=="A")
  type=2
if(player=="B")
  type=1
  if(type==null)
    return false
for (let row = 0; row < this.gameBoard.length; row++){
  for (let col = 0; col < this.gameBoard[row].length - 3; col++){
  if (this.gameBoard[row][col] != 0 &&this.gameBoard[row][col] != type&& this.gameBoard[row][col] == this.gameBoard[row][col+1] &&this.gameBoard[row][col] == this.gameBoard[row][col+2] && this.gameBoard[row][col] == this.gameBoard[row][col+3]){
  return true;
  }
  }
  }
  return false;
}
game.prototype.Vert=function(player){
  let type=null
  if(player=="A")
    type=2
  if(player=="B")
    type=1
    if(type==null)
      return false
for (let col = 0; col < this.gameBoard[0].length; col++){
  for (let row = 0; row < this.gameBoard.length - 3; row++){
  if (this.gameBoard[row][col] != 0 && this.gameBoard[row][col] != type&&this.gameBoard[row][col] == this.gameBoard[row+1][col] &&this.gameBoard[row][col] == this.gameBoard[row+2][col] && this.gameBoard[row][col] == this.gameBoard[row+3][col]){
      return true;
      }
    }
  }
}

game.prototype.Diag1=function(player){
   let type=null
  if(player=="A")
    type=2
  if(player=="B")
    type=1
    if(type==null)
      return false
for (let row = 0; row < this.gameBoard.length - 3; row++){
  for (let col = 0; col < this.gameBoard[row].length - 3; col++){
  if (this.gameBoard[row][col] != 0 && this.gameBoard[row][col] != type && this.gameBoard[row][col] == this.gameBoard[row+1][col+1] && this.gameBoard[row][col] == this.gameBoard[row+2][col+2] && this.gameBoard[row][col] == this.gameBoard[row+3][col+3]){
  return true;
  }
  }
  }
}

game.prototype.Diag2=function(player){
  let type=null
  if(player=="A")
    type=2
  if(player=="B")
    type=1
    if(type==null)
      return false
for (let row = 0; row < this.gameBoard.length - 3; row++){
  for (let col = 3; col < this.gameBoard[row].length; col++){
  if (this.gameBoard[row][col] != 0 && this.gameBoard[row][col] != type && this.gameBoard[row][col] == this.gameBoard[row+1][col-1] && this.gameBoard[row][col] == this.gameBoard[row+2][col-2] && this.gameBoard[row][col] == this.gameBoard[row+3][col-3]){
  return true;
  }
  }
  }
}
module.exports = game;