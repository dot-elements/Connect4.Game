
var connection= new WebSocket("ws://localhost:3000");
var plyr;//Pocola was here
var minutesLabel = document.getElementById("minutes");
var secondsLabel = document.getElementById("seconds");
var totalSeconds = 0;
//console.log(allCookies);
function sendClickPos(message){
     connection.send(JSON.stringify(message));
     console.log(i);
}
function sentPos(){
    //TODO:
}
function getPlyr(){
    return plyr;
}
connection.onmessage= function(e){
    console.log(e.data);
    if(e.data=="YOU WIN"||e.data=="YOU LOSE"){
        alert(e.data);
        window.location.replace("/")
    }
    if(e.data=="GameDisconnect"){
        alert("The other player disconnected");
        window.location.replace("/")

    }
    if( plyr === undefined ){
        plyr=e.data
        console.log(plyr)
        //set player red turn here;
        addHilightf(plyr)
        setPlayerOnBoard(plyr);
        
       
    }else if(e.data==="StartGame"){
        console.log("XD")
         $('.loadingOverlay').hide();
         
         setInterval(setTime, 1000);
         //setTime();
         setCookie()
       
    }else if(e.data=="Wrong Move!"){
        goMove();

    }else{
        let obj=JSON.parse(e.data);
        console.log(obj.player);
        addColor(obj.row,obj.colum,obj.player);
        //TODO: give other player hilight
        addHilight(obj.player);
        //console.log(obj.player);
       /* if( obj.hasPlayer==1){
            console.log("XD")
            $('.loadingOverlay').hide();
        }*/
    }
    
  
}